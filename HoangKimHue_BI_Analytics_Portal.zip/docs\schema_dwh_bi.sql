-- ==============================================================================
-- HỆ THỐNG BUSINESS INTELLIGENCE: CƠ SỞ DỮ LIỆU KHO DỮ LIỆU (DATA WAREHOUSE)
-- LƯỢC ĐỒ HÌNH SAO (STAR SCHEMA) & BỘ CHỈ SỐ ĐO LƯỜNG TỰ ĐỘNG
-- Học phần: AI301 - Session 03 | Sales Lead Qualification Engine
-- Tương thích: PostgreSQL / Azure SQL / Snowflake / BigQuery
-- ==============================================================================

-- 1. BẢNG CHIỀU: THÔNG TIN DOANH NGHIỆP (DIM_COMPANY)
CREATE TABLE dim_company (
    company_id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    industry VARCHAR(100) NOT NULL,
    employee_count INT DEFAULT 0,
    annual_revenue_raw VARCHAR(50),
    annual_revenue_vnd NUMERIC(18, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. BẢNG CHIỀU: THÔNG TIN NGƯỜI ĐẠI DIỆN LIÊN HỆ (DIM_CONTACT)
CREATE TABLE dim_contact (
    contact_id SERIAL PRIMARY KEY,
    contact_name VARCHAR(150) NOT NULL,
    title VARCHAR(150),
    authority_level VARCHAR(100),
    email VARCHAR(150),
    phone VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. BẢNG CHIỀU: NGUỒN TIẾP CẬN MARKETING (DIM_LEAD_SOURCE)
CREATE TABLE dim_lead_source (
    source_id SERIAL PRIMARY KEY,
    source_name VARCHAR(150) NOT NULL,
    channel_type VARCHAR(50), -- Offline Event, Organic Inbound, Open Web Form
    cost_per_acquisition NUMERIC(15, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

-- 4. BẢNG CHIỀU: MA TRẬN CHẤM ĐIỂM BANT (DIM_SCORING_MATRIX)
CREATE TABLE dim_scoring_matrix (
    rule_id SERIAL PRIMARY KEY,
    criteria VARCHAR(50) NOT NULL, -- Budget, Authority, Need, Timeline
    tier_name VARCHAR(150) NOT NULL,
    min_value NUMERIC(18, 2),
    max_value NUMERIC(18, 2),
    points_awarded INT NOT NULL
);

-- 5. BẢNG SỰ KIỆN CHÍNH: TƯƠNG TÁC KHÁCH HÀNG TIỀM NĂNG (FACT_LEAD_INTERACTIONS)
CREATE TABLE fact_lead_interactions (
    interaction_id SERIAL PRIMARY KEY,
    lead_id VARCHAR(50) UNIQUE NOT NULL, -- Mã LD-2024-XXX
    company_id INT REFERENCES dim_company(company_id),
    contact_id INT REFERENCES dim_contact(contact_id),
    source_id INT REFERENCES dim_lead_source(source_id),
    
    -- Các giá trị ghi nhận
    budget_amount_vnd NUMERIC(18, 2) DEFAULT 0,
    timeline_stated VARCHAR(100),
    need_urgency_stated VARCHAR(100),
    inquiry_text TEXT,
    
    -- Điểm số BANT tính toán
    score_budget INT DEFAULT 0,
    score_authority INT DEFAULT 0,
    score_need INT DEFAULT 0,
    score_timeline INT DEFAULT 0,
    total_bant_score INT DEFAULT 0,
    
    -- Phân khúc và Trạng thái xử lý
    segment VARCHAR(50) NOT NULL, -- Hot Lead (SQL), Warm Lead (MQL), Unqualified
    assigned_ae_id VARCHAR(100),
    handover_sla_hours NUMERIC(4, 2) DEFAULT 2.0,
    first_response_time_minutes INT,
    is_sla_breached BOOLEAN DEFAULT FALSE,
    crm_deal_id VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INDEXES TỐI ƯU HÓA TRUY VẤN CHO POWER BI VÀ ANALYTICS
-- ==============================================================================
CREATE INDEX idx_fact_lead_segment ON fact_lead_interactions(segment);
CREATE INDEX idx_fact_lead_bant_score ON fact_lead_interactions(total_bant_score);
CREATE INDEX idx_dim_company_industry ON dim_company(industry);
CREATE INDEX idx_fact_lead_source ON fact_lead_interactions(source_id);

-- ==============================================================================
-- VIEWS PHỤC VỤ TRỰC QUAN HÓA POWER BI
-- ==============================================================================

-- VIEW 1: BẢNG CHỈ SỐ KPI ĐIỀU HÀNH CHIẾN LƯỢC (EXECUTIVE KPI SUMMARY)
CREATE OR REPLACE VIEW vw_executive_kpis AS
SELECT 
    COUNT(*) AS total_leads,
    COUNT(CASE WHEN segment = 'Hot Lead (SQL)' THEN 1 END) AS hot_sql_count,
    COUNT(CASE WHEN segment = 'Warm Lead (MQL)' THEN 1 END) AS warm_mql_count,
    COUNT(CASE WHEN segment = 'Unqualified / Spam' THEN 1 END) AS spam_count,
    
    ROUND(COUNT(CASE WHEN segment = 'Hot Lead (SQL)' THEN 1 END) * 100.0 / COUNT(*), 1) AS sql_conversion_rate_pct,
    
    SUM(budget_amount_vnd) AS total_pipeline_value_vnd,
    SUM(CASE WHEN segment = 'Hot Lead (SQL)' THEN budget_amount_vnd ELSE 0 END) AS sql_pipeline_value_vnd,
    
    ROUND(SUM(CASE WHEN segment = 'Hot Lead (SQL)' THEN budget_amount_vnd ELSE 0 END) * 100.0 / NULLIF(SUM(budget_amount_vnd), 0), 1) AS sql_value_share_pct,
    
    ROUND(AVG(CASE WHEN segment = 'Hot Lead (SQL)' THEN budget_amount_vnd END), 0) AS avg_deal_size_sql_vnd,
    ROUND(AVG(total_bant_score), 1) AS avg_pipeline_bant_score
FROM fact_lead_interactions;

-- VIEW 2: PHÂN TÍCH HIỆU SUẤT THEO NGÀNH NGHỆ KINH TẾ (INDUSTRY PERFORMANCE)
CREATE OR REPLACE VIEW vw_industry_breakdown AS
SELECT 
    c.industry,
    COUNT(f.interaction_id) AS total_leads,
    COUNT(CASE WHEN f.segment = 'Hot Lead (SQL)' THEN 1 END) AS sql_leads,
    SUM(f.budget_amount_vnd) AS total_budget_vnd,
    ROUND(AVG(f.budget_amount_vnd), 0) AS avg_budget_per_lead_vnd,
    ROUND(AVG(c.employee_count), 0) AS avg_employees,
    ROUND(SUM(f.budget_amount_vnd) * 100.0 / SUM(SUM(f.budget_amount_vnd)) OVER(), 1) AS budget_share_pct
FROM fact_lead_interactions f
JOIN dim_company c ON f.company_id = c.company_id
GROUP BY c.industry
ORDER BY total_budget_vnd DESC;

-- VIEW 3: GIÁM SÁT CAM KẾT SLA TIẾP CẬN HOT LEADS (SLA MONITORING)
CREATE OR REPLACE VIEW vw_sla_monitoring AS
SELECT 
    f.lead_id,
    c.company_name,
    c.industry,
    ct.contact_name,
    ct.title,
    ct.phone,
    f.budget_amount_vnd,
    f.total_bant_score,
    f.created_at,
    f.first_response_time_minutes,
    CASE 
        WHEN f.first_response_time_minutes IS NULL THEN 'ĐANG CHỜ TIẾP CẬN'
        WHEN f.first_response_time_minutes <= (f.handover_sla_hours * 60) THEN 'ĐẠT CHUẨN SLA'
        ELSE 'VI PHẠM SLA'
    END AS sla_status,
    f.assigned_ae_id
FROM fact_lead_interactions f
JOIN dim_company c ON f.company_id = c.company_id
JOIN dim_contact ct ON f.contact_id = ct.contact_id
WHERE f.segment = 'Hot Lead (SQL)'
ORDER BY f.created_at DESC;


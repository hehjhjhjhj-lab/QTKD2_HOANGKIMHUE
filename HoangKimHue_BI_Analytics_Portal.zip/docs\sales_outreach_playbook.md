# SÁCH LƯỢC TIẾP CẬN KHÁCH HÀNG DOANH NGHIỆP CÁ NHÂN HÓA
## (PERSONALIZED B2B SALES OUTREACH PLAYBOOK)
**Dự án:** AI301 – BANT Sales Lead Qualification & Pipeline Automation  
**Tài liệu đi kèm:** Báo cáo Khoa học Business Intelligence & Power BI Executive Dashboard  
**Phân quyền:** Dành riêng cho Đội ngũ Account Executives (AE) & Marketing Automation Team  

---

## PHẦN 1: KỊCH BẢN TIẾP CẬN CÁ NHÂN HÓA CHO HOT LEADS (SQL)
> **Cam kết SLA:** Bàn giao trực tiếp cho Senior AE tiếp cận trong vòng **dưới 2.0 giờ** kể từ khi Lead ghi nhận trên hệ thống.  
> **Mục tiêu:** Thiết lập cuộc hẹn khảo sát trực tiếp (Discovery Call / Onsite Meeting) và trình diễn giải pháp mẫu (PoC Demo) trong vòng 5 ngày làm việc.

---

### Mẫu 1.1: Khối Doanh nghiệp Logistics & Vận tải Chuỗi
* **Đối tượng tiếp cận tiêu biểu:** 
  * Ông Võ Ngọc Sơn – Chủ tịch HĐQT, Tập đoàn Hóa chất Đại Nam (LD-001)
  * Bà Dương Thị Minh – Giám đốc Chuyển đổi số, Tập đoàn Logistics Phú Hưng (LD-002)
  * Ông Võ Thành Dũng – Giám đốc Chuyển đổi số, Tập đoàn Logistics Thiên Long (LD-016)
* **Quy mô:** $1,200 - 2,800$ nhân viên | Ngân sách: $600\text{ triệu} - 1.5\text{ tỷ VNĐ}$
* **Nỗi đau trọng tâm:** Tắc nghẽn đối soát vận đơn, tồn kho sai lệch giữa các kho trung chuyển và thiếu cảnh báo thời gian thực về rủi ro đứt gãy chuỗi cung ứng.

#### Kịch bản Email tiếp cận (Gửi trực tiếp từ Senior AE):
```text
Tiêu đề: [Giải pháp AI Agent x ERP] Đề xuất tối ưu hóa tồn kho và chuỗi cung ứng cho {{Tên_Doanh_Nghiệp}}

Kính gửi {{Danh_xưng}} {{Họ_Tên}},

Em là {{Tên_AE}}, Chuyên viên Tư vấn Giải pháp Doanh nghiệp cao cấp tại [Tên_Công_Ty]. 

Rất vinh hạnh được kết nối cùng {{Danh_xưng}} sau Hội thảo Chuyển đổi số Enterprise Summit vừa qua. Qua trao đổi sơ bộ, em được biết {{Tên_Doanh_Nghiệp}} đang ưu tiên triển khai gấp giải pháp AI Agent tích hợp trực tiếp vào hệ thống ERP nhằm giải quyết bài toán quản trị tồn kho và tối ưu vận hành luân chuyển kho vận.

Với quy mô hơn {{Số_Nhân_Sự}} nhân sự và mạng lưới logistics phức tạp hiện nay, việc đồng bộ dữ liệu thời gian thực giữa chứng từ vận tải và mức tồn kho an toàn là chìa khóa then chốt để cắt giảm chi phí lưu kho vốn chiếm tới 15-20% chi phí vận hành.

Đội ngũ chuyên gia kỹ thuật của chúng em đã xây dựng sẵn mô hình Kiến trúc AI Agent tích hợp chuyên sâu cho ngành Logistics, giúp:
1. Tự động đối soát 100% chứng từ kho và vận đơn ERP mà không cần nhập liệu thủ công.
2. Cảnh báo sớm nguy cơ thiếu hụt/ứ đọng tồn kho theo thời gian thực với độ chính xác trên 95%.
3. Rút ngắn thời gian xử lý đơn hàng đa điểm từ 4 giờ xuống dưới 15 phút.

Để hỗ trợ {{Danh_xưng}} đánh giá tính khả thi và dự toán ROI thực tế, em xin phép được mời {{Danh_xưng}} một buổi trao đổi ngắn 30 phút (trực tiếp hoặc qua Teams) vào:
- Lựa chọn 1: 09:30 sáng Thứ Ba (ngày dd/mm)
- Lựa chọn 2: 14:30 chiều Thứ Tư (ngày dd/mm)

Em xin phép gửi kèm bản Tóm tắt Đề xuất Kỹ thuật (Executive One-Pager) dành riêng cho khối Logistics trong tệp đính kèm.

Trân trọng cảm ơn và chúc {{Danh_xưng}} một tuần làm việc hiệu quả,

{{Tên_AE}}
Senior Enterprise Account Executive | [Tên_Công_Ty]
Số điện thoại: {{SĐT_AE}} | Email: {{Email_AE}}
```

---

### Mẫu 1.2: Khối Doanh nghiệp Sản xuất Công nghiệp & Hóa chất
* **Đối tượng tiếp cận tiêu biểu:** 
  * Ông Dương Anh Tùng – Phó TGĐ Vận hành, Tập đoàn Hóa chất Việt Thành (LD-005)
  * Ông Đặng Đức Giang – Giám đốc Chuyển đổi số, Tập đoàn Tài chính Thiên Long (LD-006)
  * Ông Trần Thành An – Giám đốc Chuyển đổi số, Tập đoàn Hóa chất Việt Thành (LD-008)
* **Quy mô:** $600 - 1,800$ nhân viên | Ngân sách: $960\text{ triệu} - 2.44\text{ tỷ VNĐ}$
* **Nỗi đau trọng tâm:** Lãng phí định mức nguyên vật liệu (BOM), dữ liệu kế hoạch sản xuất rời rạc với dữ liệu kho vật tư ERP, thời gian dừng máy do thiếu phụ tùng thay thế.

#### Kịch bản Cuộc gọi trực tiếp (Phone Script 1:1 trong vòng 2 giờ):
```text
[0:00 - 0:30]: Mở đầu định danh & Tạo dựng bối cảnh
"Dạ em chào Anh/Chị {{Tên_Khách_Hàng}}, em là {{Tên_AE}} phụ trách khối Khách hàng Doanh nghiệp Sản xuất tại [Tên_Công_Ty]. Em liên hệ lại theo phiếu đăng ký ưu tiên của Anh/Chị tại Hội thảo Enterprise Summit về bài toán triển khai hệ thống AI Agent tích hợp ERP cho {{Tên_Công_Ty}} ạ. Em xin phép trao đổi nhanh với Anh/Chị 2 phút được không ạ?"

[0:30 - 1:15]: Nêu bật nỗi đau & Giải pháp cụ thể
"Dạ em thấy Anh/Chị đang có kế hoạch phê duyệt ngân sách để giải quyết triệt để bài toán tồn kho nguyên vật liệu và tối ưu kế hoạch vận hành nhà máy ngay trong tháng tới. Hiện tại bên em vừa triển khai thành công mô hình AI Agent tích hợp hệ thống ERP (SAP/Oracle) cho một tập đoàn sản xuất quy mô 1,500 nhân sự, giúp họ tự động cân bằng tồn kho nguyên liệu theo tiến độ đơn hàng và giảm 22% chi phí lưu kho chỉ sau 60 ngày."

[1:15 - 2:00]: Chốt cuộc hẹn khảo sát / Demo PoC
"Để giúp Anh/Chị và Ban Giám đốc có cái nhìn trực quan nhất trước khi phê duyệt phương án triển khai, bên em đã chuẩn bị một bản Demo mô phỏng luồng dữ liệu ERP của ngành hóa chất/sản xuất. Em có thể ghé văn phòng Anh/Chị hoặc gửi link họp trực tuyến 30 phút vào 10h sáng mai hay 14h chiều Thứ Năm thì thuận tiện cho lịch của Anh/Chị hơn ạ?"
```

---

### Mẫu 1.3: Khối Bán lẻ Chuỗi (Retail Chains) & Dược phẩm
* **Đối tượng tiếp cận tiêu biểu:**
  * Ông Phạm Minh Em – Giám đốc CNTT (CIO), Tập đoàn Logistics Thiên Long (LD-003)
  * Bà Đặng Anh Hương – CIO, Tập đoàn Dược phẩm Phú Hưng (LD-009)
  * Ông Vũ Thành Giang – Giám đốc Chuyển đổi số, Tập đoàn Hóa chất Phú Hưng (LD-012)
  * Ông Lý Thành An – CIO, Tập đoàn Bán lẻ Thiên Long (LD-019)
* **Quy mô:** $1,200 - 1,900$ nhân viên | Ngân sách: $1.4\text{ tỷ} - 1.97\text{ tỷ VNĐ}$
* **Nỗi đau trọng tâm:** Lệch pha cung - cầu tại từng điểm bán lẻ, cận date sản phẩm dược/hàng tiêu dùng, tồn kho an toàn quá cao gây đọng vốn.

#### Thông điệp Zalo ZNS / Tin nhắn Chuyên nghiệp tiếp cận nhanh:
```text
Kính gửi Anh/Chị {{Họ_Tên}} (CIO - {{Tên_Công_Ty}}),
Em là {{Tên_AE}} từ Ban Giải pháp AI Doanh nghiệp [Tên_Công_Ty]. 
Cảm ơn Anh/Chị đã gửi bài toán tích hợp AI Agent vào ERP quản trị chuỗi bán lẻ tại Hội thảo Summit vừa qua. 
Đội ngũ Chuyên gia ERP & AI của chúng em đã hoàn thiện tài liệu Khảo sát Kiến trúc mẫu cho chuỗi bán lẻ quy mô trên 1,000 nhân sự nhằm:
✓ Tự động dự báo nhu cầu hàng hóa từng cửa hàng (Demand Forecasting AI).
✓ Đề xuất điều chuyển tồn kho liên kho tự động, giảm 35% nguy cơ hàng cận date.
Em xin phép gửi tài liệu này qua email của Anh/Chị và kết nối Zalo để tiện hỗ trợ Anh/Chị lịch Demo trực tiếp trong tuần này ạ. Trân trọng cảm ơn Anh/Chị!
```

---

## PHẦN 2: CHUỖI DRIP EMAIL MARKETING TỰ ĐỘNG CHO WARM LEADS (MQL)
> **Phân khúc mục tiêu:** 30 Leads ngành May mặc, Cơ khí, Thương mại dịch vụ (LD-031 đến LD-060).  
> **Đặc điểm:** Ngân sách $100 - 400\text{ triệu VNĐ}$, tiến độ 3-6 tháng, người liên hệ là Trưởng phòng Mua hàng / Kỹ sư trưởng.  
> **Cơ chế:** Tự động kích hoạt qua Marketing Automation (HubSpot/Mailchimp) với tần suất 5-7 ngày/email.

```
       [Day 0] Ingestion & Chào mừng
          │
          ▼
       [Kỳ 1: Ngày 1] Gửi Whitepaper & Khảo sát Hiện trạng Ngành
          │
          ▼
       [Kỳ 2: Ngày 5] Case Study: Doanh nghiệp May mặc / Cơ khí cắt giảm 30% chi phí
          │
          ▼
       [Kỳ 3: Ngày 10] Tặng Bảng tính Excel tự động tính ROI khi ứng dụng AI Agent
          │
          ▼
       [Kỳ 4: Ngày 17] Thư mời tham dự Webinar chuyên đề: "ERP AI Agent cho doanh nghiệp SME"
          │
          ▼
       [Kỳ 5: Ngày 25] Lời đề nghị Bản dùng thử có hướng dẫn (Guided Trial / PoC Đóng gói)
```

### Kỳ 1 (Gửi sau 24h đăng ký): Trao gửi Giá trị chuyên môn (Whitepaper)
* **Tiêu đề:** Tặng Bạn: Báo cáo Xu hướng Ứng dụng AI Agent trong Tối ưu hóa Vận hành Doanh nghiệp 2024
* **Nội dung:** Cảm ơn bạn đã quan tâm. Gửi kèm Whitepaper 30 trang phân tích các điểm nghẽn phổ biến nhất của các doanh nghiệp quy mô 100-300 nhân sự khi mở rộng chuỗi cung ứng và cách AI Agent giúp giải quyết mà không cần thay thế ERP hiện tại.

### Kỳ 2 (Ngày thứ 5): Câu chuyện Khách hàng Thực tế (Case Study)
* **Tiêu đề:** Doanh nghiệp sản xuất may mặc 250 nhân sự đã tiết kiệm 450 triệu/năm như thế nào?
* **Nội dung:** Kể câu chuyện thực tế về một nhà máy may mặc gặp khó khăn trong theo dõi tiến độ đơn hàng và nguyên phụ liệu tồn kho. Trình bày các con số định lượng sau 3 tháng triển khai giải pháp AI Agent đóng gói nhanh.

### Kỳ 3 (Ngày thứ 10): Công cụ tương tác tính toán ROI (Interactive ROI Calculator)
* **Tiêu đề:** Doanh nghiệp của Bạn có thể tiết kiệm bao nhiêu chi phí với AI Agent? [Bảng tính ROI miễn phí]
* **Nội dung:** Cung cấp liên kết đến công cụ trực tuyến hoặc tệp Excel cho phép nhập số lượng nhân viên, số đơn hàng/tháng để tính ra ngay số giờ làm việc tiết kiệm được và thời gian thu hồi vốn (Payback Period).

### Kỳ 4 (Ngày thứ 17): Lời mời tham gia Hội thảo Trực tuyến (Webinar Invite)
* **Tiêu đề:** [Thư mời độc quyền] Tọa đàm trực tuyến: Tích hợp AI Agent vào ERP Doanh nghiệp thực chiến
* **Nội dung:** Mời tham gia buổi Webinar chuyên sâu cùng Giám đốc Công nghệ và các chuyên gia đầu ngành. Giải đáp trực tiếp các vướng mắc về bảo mật, chi phí triển khai và cách lập dự toán ngân sách công nghệ cho năm tới.

### Kỳ 5 (Ngày thứ 25): Đề xuất Gặp gỡ Chuyên gia & Trình diễn Giải pháp Đóng gói
* **Tiêu đề:** Bạn đã sẵn sàng xây dựng lộ trình ứng dụng AI cho {{Tên_Công_Ty}}?
* **Nội dung:** Nhắc lại mục tiêu kinh doanh của khách hàng, đề xuất một buổi tư vấn 1:1 miễn phí trong 45 phút cùng Chuyên gia Kỹ thuật để rà soát quy trình và thiết kế lộ trình triển khai phù hợp với ngân sách dự kiến của doanh nghiệp.

---

## PHẦN 3: KỊCH BẢN TỰ ĐỘNG PHẢN HỒI CHO HỒ SƠ RÁC (UNQUALIFIED / SPAM)
> **Phân khúc mục tiêu:** 20 Leads nặc danh, sinh viên xin bản miễn phí, form test (LD-061 đến LD-080).  
> **Cơ chế:** Gửi email tự động trong vòng 5 phút sau khi nộp đơn, tự động gắn tag `Unqualified / Educational` trên CRM và đóng luồng kinh doanh.

### Mẫu Email Tự Động Phản Hồi:
```text
Tiêu đề: Cảm ơn bạn đã quan tâm đến Nền tảng Trí tuệ Nhân tạo Doanh nghiệp [Tên_Công_Ty]

Xin chào bạn,

Cảm ơn bạn đã gửi thông tin liên hệ và quan tâm đến giải pháp AI Agent của [Tên_Công_Ty].

Chúng tôi nhận thấy yêu cầu của bạn đang phục vụ mục đích nghiên cứu học tập, tìm hiểu cá nhân hoặc khảo sát chung. Hiện tại, [Tên_Công_Ty] là đơn vị chuyên cung cấp các giải pháp nền tảng công nghệ chuyên sâu được may đo cho các tổ chức và doanh nghiệp quy mô vừa và lớn với hạ tầng phức tạp.

Để hỗ trợ bạn trong quá trình nghiên cứu và học tập tốt nhất, chúng tôi xin gửi tặng bạn:
1. Thư viện Tài liệu & Bài giảng Mở về AI Agent và Business Intelligence: [Đường_dẫn_học_liệu]
2. Chuỗi Video hướng dẫn thực hành xây dựng AI Agent căn bản: [Đường_dẫn_Youtube/Community]
3. Tham gia Cộng đồng Kỹ sư & Sinh viên AI Việt Nam: [Đường_dẫn_Discord/Zalo_Group]

Hệ thống sẽ lưu trữ thông tin của bạn để gửi các bản tin công nghệ định kỳ. Khi doanh nghiệp của bạn có nhu cầu triển khai các giải pháp thương mại quy mô lớn, chúng tôi rất sẵn sàng đồng hành cùng bạn trong tương lai.

Chúc bạn luôn học tập tốt và thành công trên con đường phát triển công nghệ!

Ban Hỗ trợ Cộng đồng & Giáo dục
[Tên_Công_Ty] Technology Ecosystem
```

---

## PHẦN 4: NGUYÊN TẮC QUẢN TRỊ BẢN QUYỀN & BẢO MẬT DỮ LIỆU
1. **Tuyệt đối tuân thủ Nghị định 13/2023/NĐ-CP:** Thông tin số điện thoại và email của các lãnh đạo C-Level phải được lưu trữ trong môi trường mã hóa, cấm sao chép thủ công sang các bảng tính cá nhân bên ngoài hệ thống CRM được kiểm duyệt.
2. **Quy tắc Tiếp cận Không Làm Phiền (Anti-Spam Policy):** Đối với nhóm Hot Leads, nếu sau 3 lần liên hệ (1 cuộc gọi + 1 email + 1 tin nhắn Zalo) trong vòng 7 ngày mà khách hàng không phản hồi, AE phải chuyển trạng thái sang `Follow-up Later` và kích hoạt luồng nuôi dưỡng nhẹ nhàng, tránh gây phiền hà cho lãnh đạo doanh nghiệp.
3. **Cập nhật trạng thái CRM thời gian thực:** Mọi tương tác (Call Log, Meeting Notes, Email Sent) phải được log tự động lên CRM trong vòng 15 phút sau cuộc gọi để dữ liệu trên Power BI Dashboard luôn phản ánh đúng tiến độ phễu bán hàng.


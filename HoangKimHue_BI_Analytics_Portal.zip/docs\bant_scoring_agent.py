"""
================================================================================
HỌC PHẦN: AI301 - SESSION 03 | SALES LEAD QUALIFICATION AGENT
BANT SCORING ENGINE & LEAD SEGMENTATION AUTOMATION SCRIPT
================================================================================
Mô tả:
  Kịch bản Python tự động đọc 80 leads từ `leads_dataset.csv`, chuẩn hóa dữ liệu,
  xử lý các điểm bẫy bất thường (Edge Cases / Anomalies) theo `DATA_DICTIONARY.md`,
  tính điểm 4 trụ cột BANT theo `bant_scoring_matrix.csv`, phân loại Hot/Warm/Spam
  và xuất tập dữ liệu làm giàu (enriched dataset).
================================================================================
"""

import csv
import json
import re
import sys

def clean_budget(value_str):
    """Làm sạch và chuyển đổi ngân sách sang số thực VNĐ."""
    if not value_str:
        return 0.0
    try:
        clean = re.sub(r"[^\d.]", "", str(value_str))
        return float(clean) if clean else 0.0
    except Exception:
        return 0.0

def score_budget(budget_vnd):
    """
    Tiêu chí 1: Budget (Tối đa 30 điểm)
      - >= 500,000,000 VND: 30 điểm
      - 200,000,000 - 500,000,000 VND: 20 điểm
      - 50,000,000 - 200,000,000 VND: 10 điểm
      - < 50,000,000 VND: 0 điểm
    """
    if budget_vnd >= 500_000_000:
        return 30
    elif budget_vnd >= 200_000_000:
        return 20
    elif budget_vnd >= 50_000_000:
        return 10
    else:
        return 0

def score_authority(auth_level_str):
    """
    Tiêu chí 2: Authority (Tối đa 25 điểm)
      - C-Level / Chủ tịch / Tổng Giám đốc / Quyết định trực tiếp: 25 điểm
      - Trưởng phòng / Quản lý cấp trung / Tham mưu / Influencer: 15 điểm
      - Chuyên viên / Nhân viên: 5 điểm
      - Không có thẩm quyền / Sinh viên: 0 điểm
    """
    s = (auth_level_str or "").lower()
    if "decision maker" in s or "quyết định trực tiếp" in s or "c-level" in s or "chủ tịch" in s:
        return 25
    elif "influencer" in s or "tham mưu" in s or "trưởng phòng" in s or "quản lý" in s:
        return 15
    elif "chuyên viên" in s or "nhân viên" in s:
        return 5
    else:
        return 0

def score_need(need_urgency_str):
    """
    Tiêu chí 3: Need (Tối đa 25 điểm)
    LƯU Ý BẪY DỮ LIỆU (Edge Case Trap):
      Trường 'Không có nhu cầu thực tế' chứa chuỗi 'có nhu cầu'.
      Phải kiểm tra điều kiện PHỦ ĐỊNH trước tiên!
    """
    s = (need_urgency_str or "").strip().lower()
    if "không có nhu cầu" in s or "không có nhu cầu thực tế" in s:
        return 0
    elif "rất cấp thiết" in s or "bài toán cụ thể" in s:
        return 25
    elif "trung bình" in s or "có nhu cầu nhưng chưa định hình" in s:
        return 15
    elif "tò mò" in s or "khảo sát chung chung" in s:
        return 5
    else:
        return 0

def score_timeline(timeline_str):
    """
    Tiêu chí 4: Timeline (Tối đa 20 điểm)
      - Trong vòng 1 tháng / Ưu tiên số 1: 20 điểm
      - Trong vòng 1-3 tháng / Ngay trong quý này: 15 điểm
      - Trong vòng 3-6 tháng / Đầu năm tới / Đang lập dự toán: 10 điểm
      - Không có kế hoạch / Chưa có kế hoạch / > 6 tháng: 0 điểm
    """
    s = (timeline_str or "").strip().lower()
    if "không có kế hoạch" in s or "chưa có kế hoạch" in s:
        return 0
    elif "1 tháng" in s or "tháng tới" in s:
        return 20
    elif "quý này" in s or "1-3 tháng" in s:
        return 15
    elif "3-6 tháng" in s or "đầu năm tới" in s or "dự toán" in s:
        return 10
    else:
        return 0

def qualify_lead(lead_dict):
    """Chấm điểm và phân loại một lead duy nhất."""
    budget_vnd = clean_budget(lead_dict.get("budget_amount_vnd", 0))
    b_score = score_budget(budget_vnd)
    a_score = score_authority(lead_dict.get("authority_level", ""))
    n_score = score_need(lead_dict.get("need_urgency", ""))
    t_score = score_timeline(lead_dict.get("timeline", ""))
    
    total = b_score + a_score + n_score + t_score
    
    if total >= 75:
        segment = "Hot Lead (SQL)"
        action = "Bàn giao trực tiếp cho Account Executive tiếp cận trong 2 giờ"
    elif total >= 50:
        segment = "Warm Lead (MQL)"
        action = "Đưa vào luồng Email Nurturing tự động"
    else:
        segment = "Unqualified / Cold Lead"
        action = "Lưu trữ CRM, không phân bổ nhân sự kinh doanh"
        
    return {
        "lead_id": lead_dict.get("lead_id", ""),
        "contact_name": lead_dict.get("contact_name", ""),
        "title": lead_dict.get("title", ""),
        "company": lead_dict.get("company", ""),
        "industry": lead_dict.get("industry", ""),
        "employee_count": int(lead_dict.get("employee_count", 0) or 0),
        "annual_revenue_vnd": lead_dict.get("annual_revenue_vnd", ""),
        "budget_amount_vnd": budget_vnd,
        "lead_source": lead_dict.get("lead_source", ""),
        "score_budget": b_score,
        "score_authority": a_score,
        "score_need": n_score,
        "score_timeline": t_score,
        "total_bant_score": total,
        "segment": segment,
        "recommended_action": action,
        "email": lead_dict.get("email", ""),
        "phone": lead_dict.get("phone", ""),
        "inquiry": lead_dict.get("inquiry", "")
    }

def main():
    input_file = "leads_dataset.csv"
    output_file = "leads_scored_enriched.csv"
    
    print("=" * 70)
    print("AI301 - BANT LEAD QUALIFICATION AGENT RUNNING...")
    print("=" * 70)
    
    leads = []
    with open(input_file, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            leads.append(qualify_lead(row))
            
    print(f"[*] Đã đọc và chấm điểm thành công: {len(leads)} leads.")
    
    # Thống kê tổng hợp
    segments = {}
    total_budget_by_seg = {}
    for l in leads:
        seg = l["segment"]
        segments[seg] = segments.get(seg, 0) + 1
        total_budget_by_seg[seg] = total_budget_by_seg.get(seg, 0.0) + l["budget_amount_vnd"]
        
    print("\n--- BÁO CÁO PHÂN KHÚC BANT ---")
    for seg, count in sorted(segments.items(), key=lambda x: x[1], reverse=True):
        pct = (count / len(leads)) * 100
        budget = total_budget_by_seg.get(seg, 0.0)
        print(f" > {seg:25}: {count:2} leads ({pct:5.1f}%) | Ngân sách: {budget:15,.0f} VND")
        
    # Ghi tệp kết quả
    fieldnames = list(leads[0].keys())
    with open(output_file, mode="w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(leads)
        
    print(f"\n[+] Đã lưu tập dữ liệu làm giàu vào: {output_file}")
    print("=" * 70)

if __name__ == "__main__":
    main()


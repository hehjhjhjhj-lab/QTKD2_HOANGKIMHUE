# TỪ ĐIỂN DỮ LIỆU & HƯỚNG DẪN THỰC HÀNH (DATA DICTIONARY)
## Học phần: AI301 - Session 03 | 180 Phút (Sales Lead Qualification Agent)

### 1. Tổng quan
- **Tệp dữ liệu:** `leads_dataset.csv` & `leads_dataset.csv` (80 Leads doanh nghiệp).
- **Tệp ma trận BANT:** `bant_scoring_matrix.csv`.
- **Mục tiêu:** Sinh viên chạy Agent trên Google Antigravity để tự động đọc 80 Leads, tính điểm BANT bằng Python script, phân loại thành Hot/Warm/Unqualified và soạn thảo thông điệp tiếp cận cá nhân hóa.

### 2. Dữ liệu gài bẫy (Edge Cases & Anomalies)
Bộ dữ liệu chứa 20 Leads thuộc nhóm LD-2024-061 đến 080 (Junk/Spam) nhằm kiểm chứng năng lực của Agent trong việc:
- Nhận diện các Lead không có ngân sách hoặc cố tình khai khống.
- Phát hiện các yêu cầu nặc danh từ đối thủ thăm dò hoặc sinh viên xin bản miễn phí.
- Bảo vệ tài nguyên của đội ngũ Sales doanh nghiệp khỏi việc tiếp cận lãng phí.
